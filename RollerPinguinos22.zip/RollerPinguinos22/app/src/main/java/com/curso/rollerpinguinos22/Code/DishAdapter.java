package com.curso.rollerpinguinos22.Code;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.curso.rollerpinguinos22.R;
import com.curso.rollerpinguinos22.entidades.Alumno;

import java.util.ArrayList;
import java.util.List;

public class DishAdapter extends ArrayAdapter<Alumno> {
    private Context ct;
    private ArrayList<Alumno> arr;
    ImageRounded imageRounded = new ImageRounded();

    public DishAdapter(@NonNull Context context, int resource, @NonNull List<Alumno> objects) {
        super(context, resource, objects);
        this.ct = context;
        this.arr = new ArrayList<>(objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater i = (LayoutInflater) ct.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = i.inflate(R.layout.awnitem_dish, null);
        }
        if (arr.size() > 0) {
            Alumno d = arr.get(position);
            TextView txtNombreCompleto = convertView.findViewById(R.id.txtNombre_alumno);
            TextView txtMatricula = convertView.findViewById(R.id.txtMatricula);
            txtNombreCompleto.setText(d.getNombre_alumno() + " " + d.getApellidoP_alumno() + " " + d.getApellidoM_alumno());
            txtMatricula.setText(d.getMatricula_alumno());
        }
        return convertView;
    }
}
