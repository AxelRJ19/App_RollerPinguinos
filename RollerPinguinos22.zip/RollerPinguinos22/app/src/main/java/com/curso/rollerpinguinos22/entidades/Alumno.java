package com.curso.rollerpinguinos22.entidades;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.loopj.android.http.Base64;

public class Alumno {
    private int Matricula_alumno;
    private Bitmap Foto_alumno;
    private String dato_alumno;
    private String Nombre_alumno, ApellidoP_alumno, ApellidoM_alumno;

    public int getMatricula_alumno() {
        return Matricula_alumno;
    }

    public void setMatricula_alumno(int matricula_alumno) {
        Matricula_alumno = matricula_alumno;
    }

    public Bitmap getFoto_alumno() {
        return Foto_alumno;
    }

    public void setFoto_alumno(Bitmap foto_alumno) {
        Foto_alumno = foto_alumno;
    }

    public String getNombre_alumno() {
        return Nombre_alumno;
    }

    public void setNombre_alumno(String nombre_alumno) {
        Nombre_alumno = nombre_alumno;
    }

    public String getApellidoP_alumno() {
        return ApellidoP_alumno;
    }

    public void setApellidoP_alumno(String apellidoP_alumno) {
        ApellidoP_alumno = apellidoP_alumno;
    }

    public String getApellidoM_alumno() {
        return ApellidoM_alumno;
    }

    public void setApellidoM_alumno(String apellidoM_alumno) {
        ApellidoM_alumno = apellidoM_alumno;
    }

    public String getDato_alumno() {
        return dato_alumno;
    }

    public void setDato_alumno(String dato_alumno) {
        this.dato_alumno = dato_alumno;
        try{
            byte[] byteCode = Base64.decode(dato_alumno,Base64.DEFAULT);
            this.Foto_alumno = BitmapFactory.decodeByteArray(byteCode,0,byteCode.length);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public String toString(){
        return Nombre_alumno + " " +ApellidoP_alumno + " " + ApellidoM_alumno;
    }
} // Cierra la clase Producto.s
