package com.curso.rollerpinguinos22;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.curso.rollerpinguinos22.Activity.ActivityAsistencia;
import com.curso.rollerpinguinos22.Code.ImageRounded;
import com.curso.rollerpinguinos22.entidades.InfoUsuario;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class ActivityAdmin extends AppCompatActivity {
    private ImageView imgPerfil;
    private TextView txtSaludo, txtBuenos;
    private ConstraintLayout btnVentas, btnAsistencia,btnConfiguracion, btnAgregar,btnActualizar,btnEliminar;

    private int idUsuario;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;
    ImageRounded imageRounded = new ImageRounded();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        initComponent();
        request = Volley.newRequestQueue(getApplicationContext());
        String url = "https://rollerpinguinos.com/ObtenerFotoPerfil.php?image_id=" + idUsuario;
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                InfoUsuario infoUsuario = new InfoUsuario();
                JSONArray json = response.optJSONArray("usuario");
                JSONObject jsonObject = null;
                try {
                    jsonObject = json.getJSONObject(0);
                    infoUsuario.setNombre_usuario(jsonObject.optString("Nombre_usuario"));
                    infoUsuario.setDato(jsonObject.optString("foto_perfil"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (infoUsuario.getFoto_perfil() != null) {
                    Bitmap roundedBitmap = imageRounded.getRoundedBitmap(infoUsuario.getFoto_perfil());
                    imgPerfil.setImageBitmap(roundedBitmap);
                } else {
                    imgPerfil.setImageResource(R.drawable.logo);
                }
                txtSaludo.setText("Hola "+infoUsuario.getNombre_usuario()+" :)");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY); // Obtiene la hora del día en formato de 24 horas
        if (hour<=12){
            txtBuenos.setText("Buenos dias");
        } else if (hour>12 && hour<=17) {
            txtBuenos.setText("Buenas tardes");
        } else if (hour>17) {
            txtBuenos.setText("Buenas noches");
        }
        btnVentas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnAsistencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(ActivityAdmin.this, ActivityAsistencia.class);
                    startActivity(intent);
                }catch (Exception e){
                    Toast.makeText(ActivityAdmin.this, e.getMessage()+"", Toast.LENGTH_SHORT).show();
                }
            }
        });
        request.add(jsonObjectRequest);
    }

    public void initComponent() {
        imgPerfil = findViewById(R.id.imgPerfil);
        txtSaludo = findViewById(R.id.txtSaludo);
        txtBuenos = findViewById(R.id.txtBuenos);
        btnVentas = findViewById(R.id.btnVentas);
        btnAsistencia = findViewById(R.id.btnAsistencia);
        btnConfiguracion = findViewById(R.id.btnConfiguracion);
        btnAgregar = findViewById(R.id.btnAgregar);
        btnActualizar = findViewById(R.id.btnActualizar);
        btnEliminar = findViewById(R.id.btnEliminar);
        idUsuario = getIntent().getIntExtra("idUsuario", -1);
    }

    // Función para redondear el bitmap

}
