package com.curso.rollerpinguinos22;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.curso.rollerpinguinos22.methodsForDB.SelectDB;
import com.loopj.android.http.AsyncHttpClient;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
private ImageView imgLogo,imgFacebook;
private EditText edtUser,pswPass;
private CardView btnLogin;
private TextView txtRegister, txtLogin;
private SelectDB selectDB;
private AsyncHttpClient client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        final ProgressDialog progressDialog = new ProgressDialog(this);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Un segundo...");
                progressDialog.show();
                String str_user = edtUser.getText().toString().trim();
                String str_pass = pswPass.getText().toString().trim();
                String url = "https://rollerpinguinos.com/LoginPinguinos.php";
                Map<String,String> params = new HashMap<String, String>();
                params.put("Usuario",str_user);
                params.put("Password",str_pass);
                selectDB = new SelectDB(MainActivity.this, url, params, new SelectDB.CodeBlockWithResponse() {
                    @Override
                    public void execute(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            int superUsuario = jsonArray.getInt(0);
                            int idUsuario = jsonArray.getInt(1);
                            if (superUsuario == 1){
                                Intent intent = new Intent(getApplicationContext(), ActivityAdmin.class);
                                intent.putExtra("idUsuario",idUsuario);
                                startActivity(intent);
                            } else if (superUsuario == 0) {
                                Intent intent = new Intent(getApplicationContext(), ActivityEmployee.class);
                                intent.putExtra("id_usuario", idUsuario);
                                startActivity(intent);
                            } else if (response.equalsIgnoreCase("1454")) {
                                Toast.makeText(MainActivity.this, "Usuario y/o Contraseña incorrectas", Toast.LENGTH_SHORT).show();
                            }
                        }catch (JSONException e){
                            Toast.makeText(MainActivity.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        });
        txtRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ActivityRegister.class);
                startActivity(intent);
            }
        });
    }
    public void initComponents(){
        imgLogo = findViewById(R.id.imgLogo);
        imgFacebook = findViewById(R.id.imgFacebook);
        edtUser = findViewById(R.id.edtUser);
        pswPass = findViewById(R.id.pswPass);
        btnLogin = findViewById(R.id.btnLogin);
        txtRegister = findViewById(R.id.txtRegister);
        txtLogin = findViewById(R.id.txtLogin);
    }
}