package com.curso.rollerpinguinos22.methodsForDB;

import android.app.Activity;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;

import java.util.Map;

public class SelectDB {
private AsyncHttpClient client;
    public SelectDB(Activity activity, String url, final Map<String, String> params, final CodeBlockWithResponse codeBlock) {
        RequestQueue queue = Volley.newRequestQueue(activity);
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                    codeBlock.execute(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity, error.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }){
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Aquí establecemos los parámetros para la solicitud
            }
        };
        queue.add(request);
    }
    public SelectDB(){

    }

    public interface CodeBlock {
        void execute();
    }
    public interface CodeBlockWithResponse {
        void execute(String response);
    }
}
