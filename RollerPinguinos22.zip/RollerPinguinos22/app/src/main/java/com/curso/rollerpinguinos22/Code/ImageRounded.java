package com.curso.rollerpinguinos22.Code;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;

public class ImageRounded {
    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int targetWidth = 150; // Cambia este valor según tus necesidades
        int targetHeight = 150; // Cambia este valor según tus necesidades

        Bitmap targetBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(targetBitmap);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.WHITE);

        Rect rect = new Rect(0, 0, targetWidth, targetHeight);
        RectF rectF = new RectF(rect);
        float radius = targetWidth / 2.0f;

        canvas.drawRoundRect(rectF, radius, radius, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));

        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, false);
        canvas.drawBitmap(resizedBitmap, rect, rect, paint);

        return targetBitmap;
    }
}
