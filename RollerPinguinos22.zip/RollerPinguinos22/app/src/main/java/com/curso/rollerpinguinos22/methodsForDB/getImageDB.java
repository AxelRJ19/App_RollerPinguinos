package com.curso.rollerpinguinos22.methodsForDB;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.curso.rollerpinguinos22.entidades.InfoUsuario;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class getImageDB {
    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;
    public void loadPerfil(ImageView img, String url , Activity activity){
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                InfoUsuario infoUsuario = new InfoUsuario();
                JSONArray json = response.optJSONArray("usuario");
                JSONObject jsonObject = null;
                try{
                    jsonObject=json.getJSONObject(0);
                    infoUsuario.setNombre_usuario(jsonObject.optString("nombre_usuario"));
                    infoUsuario.setDato(jsonObject.optString("foto_perfil"));
                    Toast.makeText(activity, "bien", Toast.LENGTH_SHORT).show();
                }catch (JSONException e){
                    Toast.makeText(activity, e.getMessage()+"", Toast.LENGTH_SHORT).show();
                }
                img.setImageBitmap(null);
                img.setBackground(new BitmapDrawable(Resources.getSystem(),infoUsuario.getFoto_perfil()));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity, error.getMessage()+"", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
