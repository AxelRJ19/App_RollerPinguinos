package com.curso.rollerpinguinos22.Activity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.curso.rollerpinguinos22.Code.DishAdapter;
import com.curso.rollerpinguinos22.R;
import com.curso.rollerpinguinos22.entidades.Alumno;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class ActivityAsistencia extends AppCompatActivity {
    ListView lsvDish;
    private AsyncHttpClient cliente;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asistencia);
        initComponents();
        cliente = new AsyncHttpClient();
            obtenerAlumnos("");
    }
    private void obtenerAlumnos(String matricula) {
        String url = "https://rollerpinguinos.com/PasedeLista.php?matricula="+matricula;
        cliente.post(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                if (statusCode == 200) {
                    listarAlumnos(new String(responseBody));
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ActivityAsistencia.this, error.getMessage()+"", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void listarAlumnos(String respuesta) {
        ArrayList<Alumno> lista = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(respuesta);
            for (int i = 0; i < jsonArray.length(); i++) {
                Alumno a = new Alumno();
                a.setMatricula_alumno(jsonArray.getJSONObject(i).getInt("Matricula_alumno"));
                a.setNombre_alumno(jsonArray.getJSONObject(i).getString("Nombre_alumno"));
                a.setApellidoP_alumno(jsonArray.getJSONObject(i).getString("ApellidoP_alumno"));
                a.setApellidoM_alumno(jsonArray.getJSONObject(i).getString("ApellidoM_alumno"));
                lista.add(a);
            }
            DishAdapter dishAdapter = new DishAdapter(this,0,lista);
            lsvDish.setAdapter(dishAdapter);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage()+"", Toast.LENGTH_SHORT).show();
        }
    }
    public void initComponents(){
        lsvDish = findViewById(R.id.lsvDish);
    }
}